﻿using System;
using System.Collections.Generic;
using System.Text;
using Talent.Servises;

namespace Talent.ViewModels
{
    class ProfileViewModel : BaseViewModel
    {
        public ProfileViewModel()
        {
            Title = "Профиль";
        }
    }
}
