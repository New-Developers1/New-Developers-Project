﻿using System;
using System.Collections.Generic;
using System.Text;
using Talent.Servises;

namespace Talent.ViewModels
{
    class TargetViewModel : BaseViewModel
    {
        public TargetViewModel()
        {
            Title = "Скидки";
        }
    }
}
