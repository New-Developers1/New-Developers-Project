﻿using System;
using System.Collections.Generic;
using System.Text;
using Talent.Servises;

namespace Talent.ViewModels
{
    class NewsViewModel : BaseViewModel
    {
        public NewsViewModel()
        {
            Title = "Новости";
        }
    }
}
