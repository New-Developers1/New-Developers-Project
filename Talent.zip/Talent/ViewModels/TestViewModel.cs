﻿using System;
using System.Windows.Input;
using Talent.Servises;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace Talent.ViewModels
{
    public class TestViewModel : BaseViewModel
    {
        public TestViewModel()
        {
            Title = "Тесты";
            OpenWebCommand1 = new Command(async () => await Browser.OpenAsync("https://profilum.ru/test-na-professiyu"));
            OpenWebCommand2 = new Command(async () => await Browser.OpenAsync("https://test.skillfolio.ru/anonymous/adult"));
            OpenWebCommand3 = new Command(async () => await Browser.OpenAsync("http://bilet-help.worldskills.ru/"));
        }
        public ICommand OpenWebCommand1 { get; }
        public ICommand OpenWebCommand2 { get; }
        public ICommand OpenWebCommand3 { get; }
    }
}