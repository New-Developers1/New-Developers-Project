﻿using System;
using System.Linq;
using Talent.Views;
using Xamarin.Forms;

namespace Talent
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
            this.CurrentItem.CurrentItem = homePage;
            //Routing.RegisterRoute(nameof(SignPage), typeof(SignPage));
            //Routing.RegisterRoute(nameof(RegistPage), typeof(RegistPage));
            //Routing.RegisterRoute(nameof(FormPage), typeof(FormPage));
            //object id;
            //if (App.Current.Properties.TryGetValue("Id", out id))
            //    Route(nameof(SignPage));
            //else
            //    Route(nameof(RegistPage));
        }

        private async void Route(string page)
        {
            try
            {
                await ((Shell)App.Current.MainPage).GoToAsync(page);
            }
            catch(NullReferenceException e)
            {
                DisplayAlert("Уведомление", "Пришло новое сообщение", "ОK");
            }
        }
    }
}
