﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using static Talent.Modules.WorkHashModule;

namespace Talent.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class FormPage : ContentPage
    {
        bool confirm = false;
        Entry pass;
        public FormPage()
        {
            InitializeComponent();
        }
        public void Text_Changed(object obj, EventArgs e)
        {
           pass = (Entry)FindByName("Pass");
            if (pass.Text.Length > 6)
                if (pass.Text == ((Entry)FindByName("Pass2")).Text)
                {
                    confirm = true;
                    Output();
                }
                else
                {
                    confirm = false;
                    Output(true, "Пароли не сопадают");
                }
            else
            {
                confirm = false;
                Output(true, "Пароль слишком маленький");
            }
        }

        public void Click_Button(object obj, EventArgs e)
        {
            if (confirm)
            {
                pass = (Entry)FindByName("Pass");
                string hash, salt;
                Generate(pass.Text,out hash,out salt);
                //
                Route("//news");
            }
        }
        private async void Route(string page)
        {
            await Shell.Current.GoToAsync(page);
        }

        private void Output(bool check = false, string text = null)
        {
            ((Label)FindByName("OutputLabel")).Text = text;
            ((Frame)FindByName("OutputDiv")).IsVisible = check;
        }
    }
}