﻿using ServiceStack.Auth;

namespace Talent.Modules
{
    static class WorkHashModule
    {
       static public void Generate(string password, out string hash, out string salt) => new SaltedHash().GetHashAndSaltString(password, out hash,out salt);
       static public bool CheckPassword(string password, string hash, string salt) => new SaltedHash().VerifyHashString(password, hash, salt);
    }
}
